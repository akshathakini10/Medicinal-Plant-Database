import sys
import os
import json
import re
import requests
from pathlib import Path
import numpy as np
import faiss
import networkx as nx
from sentence_transformers import SentenceTransformer

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

KB_FILE = PROJECT_ROOT / "data" / "integrated" / "medicinal_knowledge_base.json"
GRAPH_FILE = PROJECT_ROOT / "data" / "knowledge_graph.gml"
INDEX_FILE = PROJECT_ROOT / "data" / "vector_store" / "medicinal_plants.index"
METADATA_FILE = PROJECT_ROOT / "data" / "vector_store" / "metadata.json"

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3:latest"
EMBED_MODEL_NAME = "all-MiniLM-L6-v2"
TOP_K = 4

# ============================================================
# 1. Exact Matching & Stopwords
# ============================================================
STOPWORDS = {
    "plant", "plants", "medicinal", "medicine", "database",
    "herb", "herbs", "which", "what", "from", "indicated",
    "treating", "treat", "treats", "used", "using", "uses",
    "show", "give", "tell", "about", "the", "for", "and", "can"
}

DISEASE_REGISTRY = [
    {"name": "Prameha", "aliases": ["prameha", "meha", "diabetes", "urinary disorder", "urinary disorders"]},
    {"name": "Jvara", "aliases": ["jvara", "fever"]},
    {"name": "Arsa", "aliases": ["arsa", "arsha", "piles", "hemorrhoids"]},
    {"name": "Kustha", "aliases": ["kustha", "kushtha", "skin disease", "skin diseases", "eczema", "psoriasis"]},
    {"name": "Krmi", "aliases": ["krmi", "krimi", "worms", "parasites"]},
    {"name": "Kasa", "aliases": ["kasa", "cough", "bronchitis"]},
    {"name": "Svasa", "aliases": ["svasa", "shvasa", "asthma", "dyspnoea"]},
    {"name": "Pandu", "aliases": ["pandu", "anemia"]},
    {"name": "Grahani", "aliases": ["grahani", "ibs", "digestive disorder", "sprue"]},
    {"name": "Kamala", "aliases": ["kamala", "jaundice", "liver disorder"]},
    {"name": "Sopha", "aliases": ["sopha", "shotha", "inflammation", "swelling"]},
    {"name": "Vrana", "aliases": ["vrana", "ulcer", "wounds"]}
]

CLASSICAL_ALIASES = {
    "ashoka": ["saraca asoca", "asoka", "asokah"],
    "asoka": ["saraca asoca", "asokah"],
    "tulsi": ["ocimum tenuiflorum", "ocimum sanctum", "tulasi"],
    "tulasi": ["ocimum tenuiflorum", "ocimum sanctum"],
    "guduchi": ["tinospora cordifolia", "amrita", "amrta", "gudici", "giloy"],
    "giloy": ["tinospora cordifolia", "guduchi"],
    "neem": ["azadirachta indica", "nimba"],
    "haritaki": ["terminalia chebula", "abhaya", "harad"],
    "citraka": ["plumbago zeylanica", "chitraka", "chita"],
    "chitraka": ["plumbago zeylanica", "citraka"],
    "kutki": ["picrorhiza kurroa", "katuka", "tikta"],
    "amalaki": ["phyllanthus emblica", "emblica officinalis", "amla"],
    "amla": ["phyllanthus emblica", "emblica officinalis", "amalaki"]
}


def normalize(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\s-]", " ", text)
    return re.sub(r"\s+", " ", text)


def remove_stopwords(text: str) -> str:
    words = normalize(text).split()
    return " ".join(word for word in words if word not in STOPWORDS)


def exact_term_match(term: str, text: str) -> bool:
    if not term or not text:
        return False
    pattern = rf"(?<!\w){re.escape(normalize(term))}(?!\w)"
    return re.search(pattern, normalize(text)) is not None


# ============================================================
# 2. Disease-First Hierarchical Entity Resolver
# ============================================================
class HierarchicalResolver:
    def __init__(self, kb_path):
        with open(kb_path, "r", encoding="utf-8") as f:
            self.plants = json.load(f)

    def resolve_query(self, query: str) -> dict:
        cleaned_query = remove_stopwords(query)

        # 1. Classical Aliases (Tulsi, Ashoka, Guduchi, etc.)
        for alias, targets in CLASSICAL_ALIASES.items():
            if exact_term_match(alias, query):
                for plant in self.plants:
                    bot = normalize(str(plant.get("botanical_name", "")))
                    if any(normalize(t) in bot for t in targets):
                        return {"type": "plant", "data": plant, "matched_term": alias.title()}

        # 2. Exact Botanical Names
        for plant in self.plants:
            bot = plant.get("botanical_name", "")
            if bot and exact_term_match(bot, query):
                return {"type": "plant", "data": plant, "matched_term": bot}

        # 3. Sanskrit / Ayurvedic Drug Names
        for plant in self.plants:
            for ident in plant.get("ayurvedic_identity", []):
                if isinstance(ident, dict):
                    drug = ident.get("drug_name", "")
                    translit = ident.get("transliteration", "")
                    if (drug and exact_term_match(drug, query)) or (translit and exact_term_match(translit, query)):
                        return {"type": "plant", "data": plant, "matched_term": drug or translit}

        # 4. Disease Matching (Before fuzzy or vernacular searches)
        for disease in DISEASE_REGISTRY:
            names = [disease["name"], *disease["aliases"]]
            if any(exact_term_match(name, query) for name in names):
                return {"type": "disease", "data": disease}

        # 5. Exact Vernacular Names
        words = cleaned_query.split()
        for w in words:
            if len(w) >= 4:
                for plant in self.plants:
                    vern = str(plant.get("vernacular_names", ""))
                    if exact_term_match(w, vern):
                        return {"type": "plant", "data": plant, "matched_term": w.title()}

        return {"type": "unknown", "data": None}


# ============================================================
# 3. Graph-RAG Engine with Backward Traversals & Filtered FAISS
# ============================================================
class GraphRAGService:
    def __init__(self):
        print("[*] Loading Knowledge Graph...")
        if not GRAPH_FILE.exists():
            raise FileNotFoundError(f"Knowledge Graph not found at {GRAPH_FILE}. Run 'python scripts/rag/build_graph.py' first.")
        self.G = nx.read_gml(str(GRAPH_FILE))

        print("[*] Loading FAISS Vector Index...")
        self.encoder = SentenceTransformer(EMBED_MODEL_NAME)
        self.index = faiss.read_index(str(INDEX_FILE))

        with open(METADATA_FILE, "r", encoding="utf-8") as f:
            self.metadata = json.load(f)

        print("[*] Initializing Hierarchical Resolver...")
        self.resolver = HierarchicalResolver(KB_FILE)

    def clean_context(self, text: str) -> str:
        """Strip Devanagari characters, OCR markup, and excessive whitespace."""
        text = re.sub(r"[\u0900-\u097F]+", " ", text)
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\[[^\]]*\]", " ", text)
        text = re.sub(r"(\(Dhn\)|\(Bpn\)|\(Mdn\)|\(Rjn\)|\(Cki\)|\bIl\b|\bII\b|\bI\b|\|)", " ", text)
        text = re.sub(r"[|_]{2,}", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    def get_plant_graph_details(self, plant_id: str) -> dict:
        """Forward Graph Lookup."""
        node_id = f"Plant_{plant_id}"
        if not self.G.has_node(node_id):
            return {}

        node = self.G.nodes[node_id]
        details = {
            "botanical_name": node.get("botanical_name", "N/A"),
            "sanskrit_name": node.get("sanskrit_name", "N/A"),
            "family": node.get("family", "N/A"),
            "rasa": node.get("rasa", "Not specified"),
            "virya": node.get("virya", "Not specified"),
            "vipaka": node.get("vipaka", "Not specified"),
            "systems": [],
            "diseases": []
        }

        for _, target, edge_data in self.G.out_edges(node_id, data=True):
            rel = edge_data.get("relation")
            target_node = self.G.nodes[target]
            if rel == "USED_IN":
                details["systems"].append(target_node.get("name", ""))
            elif rel == "TREATS":
                details["diseases"].append(target_node.get("name", ""))

        return details

    def get_plants_for_disease(self, disease_name: str) -> list:
        """Reverse Graph Traversal: (Disease)<-[:TREATS]-(Plant)."""
        dis_node_id = f"Disease_{disease_name.lower()}"
        if not self.G.has_node(dis_node_id):
            return []

        matched_plants = []
        for plant_node, _, edge_data in self.G.in_edges(dis_node_id, data=True):
            if edge_data.get("relation") == "TREATS":
                p_attr = self.G.nodes[plant_node]
                matched_plants.append({
                    "plant_id": p_attr.get("plant_id"),
                    "botanical_name": p_attr.get("botanical_name"),
                    "sanskrit_name": p_attr.get("sanskrit_name"),
                    "family": p_attr.get("family"),
                    "rasa": p_attr.get("rasa"),
                    "virya": p_attr.get("virya")
                })
        return matched_plants

    def retrieve_filtered_chunks(self, query: str, allowed_plant_ids: set, fetch_k: int = 50, final_k: int = TOP_K) -> list:
        """Retrieve vector chunks strictly filtered by the resolved plant_id(s)."""
        query_vec = self.encoder.encode([query], convert_to_numpy=True, normalize_embeddings=True)
        scores, indices = self.index.search(query_vec.astype(np.float32), fetch_k)

        filtered = []
        for idx in indices[0]:
            if 0 <= idx < len(self.metadata):
                item = self.metadata[idx]
                chunk_pid = str(item.get("plant_id", "")).strip()
                if chunk_pid in allowed_plant_ids:
                    cleaned = self.clean_context(item.get("text", ""))
                    if cleaned and cleaned not in filtered:
                        filtered.append(cleaned)
                    if len(filtered) >= final_k:
                        break
        return filtered

    def query(self, user_query: str) -> str:
        resolved = self.resolver.resolve_query(user_query)

        # -------------------------------------------------------------
        # Route 1: Disease-first Condition Query
        # -------------------------------------------------------------
        if resolved["type"] == "disease":
            disease_name = resolved["data"]["name"]
            matching_plants = self.get_plants_for_disease(disease_name)

            if not matching_plants:
                return f"No medicinal plants were found in the knowledge graph for {disease_name}."

            allowed_ids = {str(p["plant_id"]) for p in matching_plants}
            supporting_chunks = self.retrieve_filtered_chunks(user_query, allowed_ids, final_k=3)

            plants_summary = "\n".join([
                f"• {p['botanical_name']} ({p['sanskrit_name'] or 'Ayurvedic Herb'}) | Family: {p['family']} | Rasa: {p['rasa']} | Virya: {p['virya']}"
                for p in matching_plants[:8]
            ])

            graph_context = (
                f"Queried Condition: {disease_name}\n"
                f"Knowledge Graph Traversals Found ({len(matching_plants)} total verified plants):\n"
                f"{plants_summary}"
            )
            context_text = "\n---\n".join(supporting_chunks)

        # -------------------------------------------------------------
        # Route 2: Plant Entity Query
        # -------------------------------------------------------------
        elif resolved["type"] == "plant":
            plant_data = resolved["data"]
            plant_id = str(plant_data.get("plant_id", "")).strip()
            graph_data = self.get_plant_graph_details(plant_id)

            supporting_chunks = self.retrieve_filtered_chunks(user_query, {plant_id}, final_k=TOP_K)

            graph_context = (
                f"Matched Plant: {resolved.get('matched_term', plant_data.get('botanical_name'))}\n"
                f"Botanical Name: {graph_data.get('botanical_name')}\n"
                f"Family: {graph_data.get('family')}\n"
                f"Sanskrit / Drug Name: {graph_data.get('sanskrit_name')}\n"
                f"Rasa (Taste): {graph_data.get('rasa')}\n"
                f"Virya (Potency): {graph_data.get('virya')}\n"
                f"Vipaka: {graph_data.get('vipaka')}\n"
                f"Systems: {', '.join(graph_data.get('systems', []))}\n"
                f"Diseases Treated: {', '.join(graph_data.get('diseases', []))}"
            )
            context_text = "\n---\n".join(supporting_chunks)

        # -------------------------------------------------------------
        # Route 3: Unknown / Out-of-Domain Guardrail
        # -------------------------------------------------------------
        else:
            return (
                "I could not identify a recognized medicinal plant or Ayurvedic disease from your query in the database. "
                "Please verify the botanical, Sanskrit, or disease name."
            )

        # -------------------------------------------------------------
        # LLM Synthesis Layer
        # -------------------------------------------------------------
        system_prompt = (
            "You are an expert Botanical & Ayurvedic Knowledge Graph Assistant.\n"
            "Synthesize the verified Knowledge Graph facts and supporting excerpts to directly answer the question.\n"
            "Rules:\n"
            "1. Output direct, structured answers with bullet points.\n"
            "2. If answering for a disease, list the plants identified from the graph traversal.\n"
            "3. State botanical names, family, and Ayurvedic properties (Rasa, Virya, Vipaka) accurately.\n"
            "4. Do not hallucinate properties not supported by the facts."
        )

        prompt_body = (
            f"=== VERIFIED KNOWLEDGE GRAPH FACTS ===\n{graph_context}\n\n"
            f"=== FILTERED EXCERPTS ===\n{context_text}\n\n"
            f"User Question: {user_query}\n\n"
            f"Answer:"
        )

        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt_body,
            "system": system_prompt,
            "stream": False,
            "options": {"temperature": 0.1, "num_predict": 300}
        }

        try:
            print("[Graph-RAG generating...]", end="", flush=True)
            res = requests.post(OLLAMA_URL, json=payload, timeout=60)
            print("\r" + " " * 28 + "\r", end="", flush=True)
            if res.status_code == 200:
                return res.json().get("response", "").strip()
        except Exception:
            print("\r" + " " * 28 + "\r", end="", flush=True)

        return f"{graph_context}\n\nExcerpts:\n{context_text}"


if __name__ == "__main__":
    service = GraphRAGService()
    print("=" * 60)
    print("Medicinal Plant Graph-RAG Active (NetworkX + FAISS + Llama 3)")
    print("=" * 60 + "\n")

    while True:
        try:
            q = input("Ask a plant question (or 'exit'): ").strip()
            if not q or q.lower() == "exit":
                break
            print("\n" + service.query(q))
            print("\n" + "-" * 50 + "\n")
        except (KeyboardInterrupt, EOFError):
            print("\nExiting.")
            break