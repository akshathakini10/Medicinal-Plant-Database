import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from src.graph_rag import exact_term_match, HierarchicalResolver, KB_FILE

resolver = HierarchicalResolver(KB_FILE)

def test_plant_does_not_match_plantago():
    assert exact_term_match("plant", "Plantago arenaria") is False
    print("[PASS] 'plant' does not match 'Plantago'")

def test_prameha_is_resolved_as_disease():
    res = resolver.resolve_query("Which medicinal plant from the database is indicated for treating Prameha?")
    assert res["type"] == "disease", f"Expected disease, got {res['type']}"
    assert res["data"]["name"] == "Prameha"
    print("[PASS] 'Prameha' query routed to Disease engine")

def test_guduchi_is_resolved_as_plant():
    res = resolver.resolve_query("What are the Rasa and Virya of Guduchi?")
    assert res["type"] == "plant", f"Expected plant, got {res['type']}"
    assert "tinospora cordifolia" in res["data"]["botanical_name"].lower()
    print("[PASS] 'Guduchi' resolved to Tinospora cordifolia")

def test_ashoka_is_resolved_as_plant():
    res = resolver.resolve_query("What is the botanical name and family of Ashoka?")
    assert res["type"] == "plant", f"Expected plant, got {res['type']}"
    assert "saraca asoca" in res["data"]["botanical_name"].lower()
    print("[PASS] 'Ashoka' resolved to Saraca asoca")

def test_out_of_domain_query():
    res = resolver.resolve_query("What is the dosage of Paracetamol in Ayurveda?")
    assert res["type"] == "unknown"
    print("[PASS] Out-of-domain synthetic query handled cleanly")

if __name__ == "__main__":
    test_plant_does_not_match_plantago()
    test_prameha_is_resolved_as_disease()
    test_guduchi_is_resolved_as_plant()
    test_ashoka_is_resolved_as_plant()
    test_out_of_domain_query()
    print("\nAll regression tests passed successfully!")